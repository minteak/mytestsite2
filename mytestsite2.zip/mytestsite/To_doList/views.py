from django.shortcuts import render
from django.http import HttpResponse
from .models import To_doclass
from django.template import loader
# Create your views here.
To_doList2 = []
def index(request):
    To_dosite = To_doclass.objects.all()
    template = loader.get_template('To_doList/index.html')
    context = {
        'To_dosite' : To_dosite,
    }

    return HttpResponse(template.render(context, request))
    #return render(request, 'To_doList/index.html', {'To_dosite': To_dosite})
    #return HttpResponse("Hello, world. You're at the To_doList index.")

def showpage(request):
    To_dosite = To_doclass.objects.all()
    newlist1 = To_doclass('class1','cs',False)
    To_doList2.append(newlist1)
    newlist2 = To_doclass('class2','cs2',False)
    To_doList2.append(newlist2)
    newlist3 = To_doclass('class3','cs3',True)
    To_doList2.append(newlist3)
    '''if request.method == 'POST' :
        To_docontest = request.POST.get('To_docontest')
        if To_docontest :
            To_doList2.append(To_docontest)  '''

    return render(request,'To_doList/index.html',{'To_doList2': To_doList2})
