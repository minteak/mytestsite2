from django.contrib import admin
from .models import To_doclass

# Register your models here.

admin.site.register(To_doclass)