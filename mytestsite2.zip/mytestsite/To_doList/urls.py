
from django.urls import path

from . import views

urlpatterns = [

    path('', views.index, name='index'),
    path('showpage', views.showpage, name='showpage')
]
